package com.example.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.core.io.ClassPathResource;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class FeedScheduler {

	public static String TYPE = "text/csv";
	static String[] HEADERs = { "Id", "Title", "Description", "Published" };

	@Scheduled(cron = "0 0/1 * * * *") // 5 min
	public void cronJobSch() {

		Resource resource = (Resource) new ClassPathResource("classpath:700.hk.txt");
		try {
			InputStream inputStream = ((ClassPathResource) resource).getInputStream();
			csvToTutorials(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// put them in the kafka queue

	}

	public static List<TradingFeed> csvToTutorials(InputStream is) {
		try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				CSVParser csvParser = new CSVParser(fileReader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

			List<TradingFeed> tradingList = new ArrayList<TradingFeed>();

			Iterable<CSVRecord> csvRecords = csvParser.getRecords();

			for (CSVRecord csvRecord : csvRecords) {
				
			 ///   inputs single record from satya  Kafka
				
	             String name =  csvRecord.get("<TICKER>");
	             System.out.println(name);
	              
				TradingFeed trading = new TradingFeed();

				tradingList.add(trading);
			}

			return tradingList;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
		}
	}

}
