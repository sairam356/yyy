package com.example.demo;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import software.amazon.kinesis.exceptions.InvalidStateException;
import software.amazon.kinesis.exceptions.ShutdownException;
import software.amazon.kinesis.lifecycle.events.InitializationInput;
import software.amazon.kinesis.lifecycle.events.LeaseLostInput;
import software.amazon.kinesis.lifecycle.events.ProcessRecordsInput;
import software.amazon.kinesis.lifecycle.events.ShardEndedInput;
import software.amazon.kinesis.lifecycle.events.ShutdownRequestedInput;
import software.amazon.kinesis.processor.ShardRecordProcessor;
import software.amazon.kinesis.retrieval.KinesisClientRecord;

public class TrainingReaderData implements ShardRecordProcessor{

	
	public void processRecords(ProcessRecordsInput processRecordsInput) {

        // Data is read here from the Kinesis data stream
        for (KinesisClientRecord record : processRecordsInput.records()) {

            

            String originalData = "";

            try {
                byte[] b = new byte[record.data().remaining()];
                ByteBuffer byteBuf = record.data().get(b);
                originalData = new String(byteBuf.array(), "UTF-8");

              

                ObjectMapper objectMapper = new ObjectMapper();
                System.out.println(originalData);

               // TrackDto[] tracks = objectMapper.readValue(originalData, TradingFeed[].class);

                List<TradingFeed> trackDetails = new ArrayList<>();

                for (TradingFeed track : trackDetails) {

                	TradingFeed trackDetail = new TradingFeed();
                  
                    trackDetails.add(trackDetail);
                }

                //trackService.addTrack(trackDetails);

            } catch (Exception e) {
                
                System.exit(1);
            }

            try {
                /*
                 * KCL assumes that the call to checkpoint means that all records have been
                 * processed, records which are passed to the record processor.
                 */
                processRecordsInput.checkpointer().checkpoint();

            } catch (Exception e) {
                
            }
        }
    }

    public void leaseLost(LeaseLostInput leaseLostInput) {
       
    }

    public void shardEnded(ShardEndedInput shardEndedInput) {
        try {
            shardEndedInput.checkpointer().checkpoint();
        } catch (ShutdownException | InvalidStateException e) {

            e.printStackTrace();
        }
    }

    public void shutdownRequested(ShutdownRequestedInput shutdownRequestedInput) {
        try {
            shutdownRequestedInput.checkpointer().checkpoint();
        } catch (ShutdownException | InvalidStateException e) {

            e.printStackTrace();
        }
    }

	@Override
	public void initialize(InitializationInput initializationInput) {
		// TODO Auto-generated method stub
		
	}
}
