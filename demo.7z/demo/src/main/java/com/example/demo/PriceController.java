package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class PriceController {
	
	
	@Autowired
	PriceService  priceService;
	
	
	public String createPrice(@RequestBody TradingFeed tradingFeed) {
		
		 ObjectMapper mapper = new ObjectMapper();
	        String data = "";
	        try {
	             data = mapper.writeValueAsString(tradingFeed);
	             priceService.putDataIntoKinesis(data);
	        } catch (JsonProcessingException e) {
	           e.printStackTrace();
	        } catch (Exception e) {
	           e.printStackTrace();
	        }
		
		
		return "";
	}

}
