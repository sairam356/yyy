package com.example.demo;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class TradingFeed {
  
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long feedId;
	private String feedName;
	private Integer min;
	private Date dateOn;
	private String time ;
	
	private BigDecimal openPrice;
	private BigDecimal highPrice;
	private BigDecimal lowPrice;
	private BigDecimal closePrice;
	private Long  volume;
	private String mobileNumber;
	private Long openInt;
	private Date createdDt;
	private Date updatDt;
	
	
	
}
